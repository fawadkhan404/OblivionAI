# Oblivion AI ProGuard Rules
-keep class com.oblivion.ai.** { *; }
-keep class org.json.** { *; }
-keepattributes *Annotation*
-keepattributes SourceFile,LineNumberTable
-dontwarn okhttp3.**
-dontwarn okio.**
