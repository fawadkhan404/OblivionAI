package com.oblivion.ai;

import android.content.*;
import androidx.core.content.ContextCompat;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            PrefsManager prefs = new PrefsManager(context);
            if (prefs.isServiceEnabled()) {
                Intent serviceIntent = new Intent(context, OblivionService.class);
                ContextCompat.startForegroundService(context, serviceIntent);
            }
        }
    }
}
