package com.oblivion.ai;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.*;
import android.content.pm.PackageManager;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.provider.AlarmClock;
import android.provider.Settings;
import android.util.Log;
import android.window.SplashScreen;

import java.net.URLEncoder;
import java.util.*;
import java.util.regex.*;

/**
 * CommandExecutor — parses natural language commands in Urdu, Roman Urdu,
 * English, and Pashto and executes phone actions.
 */
public class CommandExecutor {

    private static final String TAG = "CommandExecutor";
    private final Context context;

    public CommandExecutor(Context context) {
        this.context = context;
    }

    /**
     * Returns a response string if command was handled, null if not a command.
     */
    public String tryExecuteCommand(String input) {
        String lower = input.toLowerCase().trim();

        // --- APP OPEN ---
        if (matches(lower, "open", "kholo", "chalo", "launch", "start")) {
            String appName = extractAfter(lower, "open", "kholo", "chalo", "launch", "start");
            if (appName != null) return openApp(appName);
        }

        // --- APP INSTALL ---
        if (matches(lower, "install", "download", "install karo")) {
            String appName = extractAfter(lower, "install", "download", "install karo");
            if (appName != null) return installApp(appName);
        }

        // --- APP UNINSTALL ---
        if (matches(lower, "delete", "uninstall", "hatao", "remove")) {
            String appName = extractAfter(lower, "delete", "uninstall", "hatao", "remove");
            if (appName != null) return uninstallApp(appName);
        }

        // --- ALARM ---
        if (lower.contains("alarm") || lower.contains("alarm lagao") || lower.contains("wake me")) {
            return setAlarm(lower);
        }

        // --- WEB SEARCH ---
        if (lower.contains("search") || lower.contains("dhundo") || lower.contains("google") ||
            lower.contains("batao") && lower.contains("kya hai")) {
            String query = extractSearchQuery(lower);
            if (query != null) return searchWeb(query);
        }

        // --- CALL ---
        if (lower.contains("call karo") || lower.contains("phone karo") || lower.contains("call")) {
            String name = extractAfter(lower, "call karo", "phone karo", "call");
            if (name != null) return makeCall(name);
        }

        // --- SMS / MESSAGE ---
        if (lower.contains("message") || lower.contains("sms") || lower.contains("text")) {
            return "Message feature: Contacts app khool raha hoon.";
        }

        // --- VOLUME ---
        if (lower.contains("volume up") || lower.contains("volume barha")) return adjustVolume(true);
        if (lower.contains("volume down") || lower.contains("volume kam")) return adjustVolume(false);
        if (lower.contains("mute") || lower.contains("silent")) return setMute(true);
        if (lower.contains("unmute") || lower.contains("sound on")) return setMute(false);

        // --- BRIGHTNESS ---
        if (lower.contains("brightness") || lower.contains("roshni")) {
            return openDisplaySettings();
        }

        // --- WIFI ---
        if (lower.contains("wifi") || lower.contains("wi-fi")) {
            return openWifiSettings();
        }

        // --- BLUETOOTH ---
        if (lower.contains("bluetooth")) {
            return openBluetoothSettings();
        }

        // --- NOTE ---
        if (lower.contains("note") || lower.contains("likhna") || lower.contains("yaad rakho")) {
            String noteText = extractAfter(lower, "note karo", "likhna", "yaad rakho", "note");
            return createNote(noteText != null ? noteText : input);
        }

        // --- TRANSLATE ---
        if (lower.contains("translate") || lower.contains("tarjuma")) {
            String text = extractAfter(lower, "translate", "tarjuma karo", "tarjuma");
            if (text != null) return translateText(text);
        }

        // --- CALCULATOR ---
        if (lower.contains("calculate") || lower.contains("hisab") || lower.contains("calculator")) {
            return openCalculator();
        }

        // --- CAMERA ---
        if (lower.contains("camera") || lower.contains("photo") || lower.contains("tasweer")) {
            return openCamera();
        }

        // --- BATTERY ---
        if (lower.contains("battery") || lower.contains("charge")) {
            return openBatterySettings();
        }

        // --- YOUTUBE ---
        if (lower.contains("youtube") || lower.contains("video chalao")) {
            String query = extractAfter(lower, "youtube pe", "youtube par", "youtube", "video chalao");
            return openYoutube(query);
        }

        // --- MAPS ---
        if (lower.contains("maps") || lower.contains("location") || lower.contains("rasta")) {
            String dest = extractAfter(lower, "maps", "location", "rasta", "navigate to");
            return openMaps(dest);
        }

        // --- TIME ---
        if (lower.contains("time") || lower.contains("waqt") || lower.contains("kitne baje")) {
            return getCurrentTime();
        }

        // --- DATE ---
        if (lower.contains("date") || lower.contains("tareekh") || lower.contains("aaj ka din")) {
            return getCurrentDate();
        }

        return null; // Not a command — let AI handle it
    }

    private boolean matches(String input, String... keywords) {
        for (String kw : keywords) {
            if (input.contains(kw)) return true;
        }
        return false;
    }

    private String extractAfter(String input, String... keywords) {
        for (String kw : keywords) {
            int idx = input.indexOf(kw);
            if (idx >= 0) {
                String after = input.substring(idx + kw.length()).trim();
                if (!after.isEmpty()) return after;
            }
        }
        return null;
    }

    private String openApp(String appName) {
        PackageManager pm = context.getPackageManager();
        String[] knownApps = {
            "whatsapp", "facebook", "instagram", "youtube", "camera",
            "settings", "gmail", "chrome", "maps", "calculator", "clock",
            "contacts", "messages", "photos", "files", "play store", "music",
            "spotify", "twitter", "telegram", "snapchat", "tiktok"
        };

        Map<String, String> packageMap = new HashMap<>();
        packageMap.put("whatsapp",    "com.whatsapp");
        packageMap.put("facebook",    "com.facebook.katana");
        packageMap.put("instagram",   "com.instagram.android");
        packageMap.put("youtube",     "com.google.android.youtube");
        packageMap.put("camera",      "com.android.camera2");
        packageMap.put("settings",    "com.android.settings");
        packageMap.put("gmail",       "com.google.android.gm");
        packageMap.put("chrome",      "com.android.chrome");
        packageMap.put("maps",        "com.google.android.apps.maps");
        packageMap.put("calculator",  "com.android.calculator2");
        packageMap.put("clock",       "com.android.deskclock");
        packageMap.put("contacts",    "com.android.contacts");
        packageMap.put("play store",  "com.android.vending");
        packageMap.put("spotify",     "com.spotify.music");
        packageMap.put("twitter",     "com.twitter.android");
        packageMap.put("telegram",    "org.telegram.messenger");
        packageMap.put("snapchat",    "com.snapchat.android");
        packageMap.put("tiktok",      "com.zhiliaoapp.musically");

        String appLower = appName.toLowerCase().trim();
        String pkg = packageMap.get(appLower);

        if (pkg != null) {
            Intent launch = pm.getLaunchIntentForPackage(pkg);
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(launch);
                return appName + " khol diya! ✅";
            }
        }

        // Try search by name in all installed apps
        List<android.content.pm.ApplicationInfo> apps = pm.getInstalledApplications(0);
        for (android.content.pm.ApplicationInfo app : apps) {
            String label = pm.getApplicationLabel(app).toString().toLowerCase();
            if (label.contains(appLower)) {
                Intent launch = pm.getLaunchIntentForPackage(app.packageName);
                if (launch != null) {
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(launch);
                    return label + " khol diya! ✅";
                }
            }
        }

        return appName + " mil nahi raha. Play Store se install karo pehle.";
    }

    private String installApp(String appName) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW,
                Uri.parse("market://search?q=" + URLEncoder.encode(appName, "UTF-8")));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
            return "Play Store mein " + appName + " search kar raha hoon... ✅";
        } catch (Exception e) {
            try {
                Intent intent = new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://play.google.com/store/search?q=" + URLEncoder.encode(appName, "UTF-8")));
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
                return "Play Store browser mein khol raha hoon " + appName + " ke liye.";
            } catch (Exception ex) {
                return "Play Store open nahi ho saka.";
            }
        }
    }

    private String uninstallApp(String appName) {
        PackageManager pm = context.getPackageManager();
        List<android.content.pm.ApplicationInfo> apps = pm.getInstalledApplications(0);
        for (android.content.pm.ApplicationInfo app : apps) {
            String label = pm.getApplicationLabel(app).toString().toLowerCase();
            if (label.contains(appName.toLowerCase())) {
                Intent intent = new Intent(Intent.ACTION_DELETE,
                    Uri.parse("package:" + app.packageName));
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
                return label + " uninstall kar raha hoon... confirm karo screen pe. ✅";
            }
        }
        return appName + " install nahi mila.";
    }

    private String setAlarm(String input) {
        try {
            // Extract time like 7:00, 6 baje, etc.
            Pattern p = Pattern.compile("(\\d{1,2})(?::(\\d{2}))?\\s*(am|pm|baje|bajay)?", Pattern.CASE_INSENSITIVE);
            Matcher m = p.matcher(input);
            int hour = 7, minute = 0;
            if (m.find()) {
                hour = Integer.parseInt(m.group(1));
                if (m.group(2) != null) minute = Integer.parseInt(m.group(2));
                String ampm = m.group(3);
                if (ampm != null && ampm.equalsIgnoreCase("pm") && hour < 12) hour += 12;
            }

            Intent alarmIntent = new Intent(AlarmClock.ACTION_SET_ALARM);
            alarmIntent.putExtra(AlarmClock.EXTRA_HOUR, hour);
            alarmIntent.putExtra(AlarmClock.EXTRA_MINUTES, minute);
            alarmIntent.putExtra(AlarmClock.EXTRA_MESSAGE, "Oblivion AI Alarm");
            alarmIntent.putExtra(AlarmClock.EXTRA_SKIP_UI, false);
            alarmIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(alarmIntent);
            return "Alarm set kar diya " + hour + ":" + String.format("%02d", minute) + " ke liye! ⏰";
        } catch (Exception e) {
            return "Alarm app khol raha hoon...";
        }
    }

    private String searchWeb(String query) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW,
                Uri.parse("https://www.google.com/search?q=" + URLEncoder.encode(query, "UTF-8")));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
            return "Google pe search kar raha hoon: " + query + " 🔍";
        } catch (Exception e) {
            return "Search open nahi ho saka.";
        }
    }

    private String makeCall(String name) {
        try {
            Intent intent = new Intent(Intent.ACTION_DIAL,
                Uri.parse("tel:" + name.replaceAll("[^0-9+]", "")));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
            return name + " ko call kar raha hoon... 📞";
        } catch (Exception e) {
            return "Call nahi ho saka.";
        }
    }

    private String adjustVolume(boolean up) {
        AudioManager am = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
        if (am != null) {
            am.adjustStreamVolume(
                AudioManager.STREAM_MUSIC,
                up ? AudioManager.ADJUST_RAISE : AudioManager.ADJUST_LOWER,
                AudioManager.FLAG_SHOW_UI
            );
            return up ? "Volume barha diya! 🔊" : "Volume kam kar diya! 🔉";
        }
        return "Volume adjust nahi ho saka.";
    }

    private String setMute(boolean mute) {
        AudioManager am = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
        if (am != null) {
            am.setRingerMode(mute ? AudioManager.RINGER_MODE_SILENT : AudioManager.RINGER_MODE_NORMAL);
            return mute ? "Phone mute kar diya! 🔇" : "Sound on kar diya! 🔔";
        }
        return "Mute nahi ho saka.";
    }

    private String openDisplaySettings() {
        Intent intent = new Intent(Settings.ACTION_DISPLAY_SETTINGS);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
        return "Display settings khol diya. Brightness wahan adjust karo. 💡";
    }

    private String openWifiSettings() {
        Intent intent = new Intent(Settings.ACTION_WIFI_SETTINGS);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
        return "WiFi settings khol diya! 📶";
    }

    private String openBluetoothSettings() {
        Intent intent = new Intent(Settings.ACTION_BLUETOOTH_SETTINGS);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
        return "Bluetooth settings khol diya! 🔵";
    }

    private String createNote(String text) {
        // Save locally
        MemoryManager mem = new MemoryManager(context);
        mem.saveNote(text);
        return "Note save kar diya: \"" + text + "\" 📝";
    }

    private String translateText(String text) {
        try {
            String url = "https://translate.google.com/?text=" + URLEncoder.encode(text, "UTF-8");
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
            return "Google Translate mein khol raha hoon: " + text;
        } catch (Exception e) {
            return "Translate nahi ho saka.";
        }
    }

    private String openCalculator() {
        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_MAIN);
        intent.addCategory(Intent.CATEGORY_APP_CALCULATOR);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            context.startActivity(intent);
            return "Calculator khol diya! 🧮";
        } catch (Exception e) {
            return "Calculator nahi mila.";
        }
    }

    private String openCamera() {
        Intent intent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            context.startActivity(intent);
            return "Camera khol diya! 📷";
        } catch (Exception e) {
            return "Camera open nahi hua.";
        }
    }

    private String openBatterySettings() {
        Intent intent = new Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            context.startActivity(intent);
            return "Battery settings khol diya! 🔋";
        } catch (Exception e) {
            return "Battery settings nahi mili.";
        }
    }

    private String openYoutube(String query) {
        try {
            String url = query != null
                ? "https://www.youtube.com/results?search_query=" + URLEncoder.encode(query, "UTF-8")
                : "https://www.youtube.com";
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
            return query != null ? "YouTube pe search: " + query + " ▶️" : "YouTube khol diya! ▶️";
        } catch (Exception e) {
            return "YouTube nahi khula.";
        }
    }

    private String openMaps(String destination) {
        try {
            String url = destination != null
                ? "https://maps.google.com/maps?q=" + URLEncoder.encode(destination, "UTF-8")
                : "https://maps.google.com";
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
            return destination != null ? destination + " ka rasta dhundh raha hoon... 🗺️" : "Maps khol diya! 🗺️";
        } catch (Exception e) {
            return "Maps nahi khula.";
        }
    }

    private String getCurrentTime() {
        Calendar cal = Calendar.getInstance();
        int hour = cal.get(Calendar.HOUR_OF_DAY);
        int min = cal.get(Calendar.MINUTE);
        String ampm = hour >= 12 ? "PM" : "AM";
        int h12 = hour % 12;
        if (h12 == 0) h12 = 12;
        return String.format("Abhi %d:%02d %s baj rahe hain. ⏰", h12, min, ampm);
    }

    private String getCurrentDate() {
        Calendar cal = Calendar.getInstance();
        String[] months = {"January","February","March","April","May","June",
                           "July","August","September","October","November","December"};
        return String.format("Aaj %d %s %d hai. 📅",
            cal.get(Calendar.DAY_OF_MONTH),
            months[cal.get(Calendar.MONTH)],
            cal.get(Calendar.YEAR));
    }

    private String extractSearchQuery(String input) {
        String[] prefixes = {"search for", "search", "google", "dhundo", "batao kya hai", "what is"};
        for (String p : prefixes) {
            int idx = input.indexOf(p);
            if (idx >= 0) {
                String after = input.substring(idx + p.length()).trim();
                if (!after.isEmpty()) return after;
            }
        }
        return input;
    }
}
