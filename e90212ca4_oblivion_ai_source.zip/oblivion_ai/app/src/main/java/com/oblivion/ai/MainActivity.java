package com.oblivion.ai;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.*;

public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_RECORD_AUDIO = 100;
    private static final int REQUEST_SPEECH_INPUT = 200;

    private RecyclerView chatRecyclerView;
    private ChatAdapter chatAdapter;
    private List<ChatMessage> messageList;
    private EditText inputField;
    private ImageButton sendBtn, micBtn;
    private TextView statusText;
    private TextToSpeech tts;
    private AIBrain aiBrain;
    private CommandExecutor commandExecutor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initViews();
        initTTS();
        initAI();
        startOblivionService();
        requestPermissions();
    }

    private void initViews() {
        chatRecyclerView = findViewById(R.id.chatRecyclerView);
        inputField       = findViewById(R.id.inputField);
        sendBtn          = findViewById(R.id.sendBtn);
        micBtn           = findViewById(R.id.micBtn);
        statusText       = findViewById(R.id.statusText);

        messageList  = new ArrayList<>();
        chatAdapter  = new ChatAdapter(messageList);
        LinearLayoutManager llm = new LinearLayoutManager(this);
        llm.setStackFromEnd(true);
        chatRecyclerView.setLayoutManager(llm);
        chatRecyclerView.setAdapter(chatAdapter);

        // Greeting
        addBotMessage("Oblivion online. Hukum karo, Tony. 🔥");

        sendBtn.setOnClickListener(v -> {
            String text = inputField.getText().toString().trim();
            if (!text.isEmpty()) {
                processUserInput(text);
                inputField.setText("");
            }
        });

        micBtn.setOnClickListener(v -> startVoiceInput());

        // Settings button
        findViewById(R.id.settingsBtn).setOnClickListener(v ->
            startActivity(new Intent(this, SettingsActivity.class))
        );

        // History button
        findViewById(R.id.historyBtn).setOnClickListener(v ->
            startActivity(new Intent(this, ChatHistoryActivity.class))
        );
    }

    private void initTTS() {
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                // Language from prefs
                PrefsManager prefs = new PrefsManager(this);
                String lang = prefs.getLanguage();
                setTTSLanguage(lang);
            }
        });
    }

    private void setTTSLanguage(String lang) {
        Locale locale;
        switch (lang) {
            case "ur": locale = new Locale("ur"); break;
            case "ps": locale = new Locale("ps"); break;
            default:   locale = Locale.ENGLISH;   break;
        }
        tts.setLanguage(locale);
        tts.setSpeechRate(0.95f);
        tts.setPitch(0.9f);
    }

    private void initAI() {
        aiBrain = new AIBrain(this);
        commandExecutor = new CommandExecutor(this);
    }

    private void startOblivionService() {
        Intent serviceIntent = new Intent(this, OblivionService.class);
        ContextCompat.startForegroundService(this, serviceIntent);
    }

    private void processUserInput(String input) {
        addUserMessage(input);
        statusText.setText("Processing...");

        // Save to history
        aiBrain.saveInteraction(input, "");

        // Run async
        new Thread(() -> {
            String response;
            // Try command first
            String cmdResult = commandExecutor.tryExecuteCommand(input);
            if (cmdResult != null) {
                response = cmdResult;
            } else {
                response = aiBrain.getResponse(input);
            }

            final String finalResponse = response;
            runOnUiThread(() -> {
                addBotMessage(finalResponse);
                speakOut(finalResponse);
                statusText.setText("Ready — Say 'Oblivion' to activate");
                aiBrain.updateLastResponse(input, finalResponse);
            });
        }).start();
    }

    private void addUserMessage(String text) {
        messageList.add(new ChatMessage(text, true));
        chatAdapter.notifyItemInserted(messageList.size() - 1);
        chatRecyclerView.scrollToPosition(messageList.size() - 1);
    }

    private void addBotMessage(String text) {
        messageList.add(new ChatMessage(text, false));
        chatAdapter.notifyItemInserted(messageList.size() - 1);
        chatRecyclerView.scrollToPosition(messageList.size() - 1);
    }

    private void speakOut(String text) {
        if (tts != null) {
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, null);
        }
    }

    private void startVoiceInput() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ur-PK");
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "ur-PK,en-US,ps-AF");
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Bolo...");
        try {
            startActivityForResult(intent, REQUEST_SPEECH_INPUT);
        } catch (Exception e) {
            Toast.makeText(this, "Voice input not available", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_SPEECH_INPUT && resultCode == RESULT_OK && data != null) {
            ArrayList<String> result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (result != null && !result.isEmpty()) {
                processUserInput(result.get(0));
            }
        }
    }

    private void requestPermissions() {
        String[] perms = {
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_EXTERNAL_STORAGE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.SEND_SMS,
            Manifest.permission.READ_CONTACTS
        };
        List<String> needed = new ArrayList<>();
        for (String p : perms) {
            if (ContextCompat.checkSelfPermission(this, p) != PackageManager.PERMISSION_GRANTED) {
                needed.add(p);
            }
        }
        if (!needed.isEmpty()) {
            ActivityCompat.requestPermissions(this, needed.toArray(new String[0]), REQUEST_RECORD_AUDIO);
        }
    }

    @Override
    protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }
}
