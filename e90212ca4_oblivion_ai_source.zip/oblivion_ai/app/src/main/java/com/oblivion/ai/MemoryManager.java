package com.oblivion.ai;

import android.content.Context;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Persistent memory — stores conversation history, notes, and user preferences
 * locally on device as JSON files.
 */
public class MemoryManager {

    private static final String TAG = "MemoryManager";
    private static final String HISTORY_FILE = "oblivion_history.json";
    private static final String NOTES_FILE   = "oblivion_notes.json";
    private static final int    MAX_HISTORY  = 100;

    private final Context context;

    public MemoryManager(Context context) {
        this.context = context;
    }

    public void save(String input, String response) {
        try {
            JSONArray history = loadHistory();
            JSONObject entry = new JSONObject();
            entry.put("input", input);
            entry.put("response", response);
            entry.put("timestamp", System.currentTimeMillis());
            entry.put("date", new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
                .format(new Date()));
            history.put(entry);

            // Keep only last MAX_HISTORY entries
            while (history.length() > MAX_HISTORY) {
                history.remove(0);
            }

            saveToFile(HISTORY_FILE, history.toString());
        } catch (Exception e) {
            Log.e(TAG, "Save error: " + e.getMessage());
        }
    }

    public void updateLast(String input, String response) {
        try {
            JSONArray history = loadHistory();
            if (history.length() > 0) {
                JSONObject last = history.getJSONObject(history.length() - 1);
                if (last.getString("input").equals(input)) {
                    last.put("response", response);
                    saveToFile(HISTORY_FILE, history.toString());
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Update error: " + e.getMessage());
        }
    }

    public String getSummary() {
        try {
            JSONArray history = loadHistory();
            if (history.length() == 0) return "No previous interactions.";

            StringBuilder sb = new StringBuilder("Recent interactions: ");
            int start = Math.max(0, history.length() - 5);
            for (int i = start; i < history.length(); i++) {
                JSONObject entry = history.getJSONObject(i);
                sb.append("[").append(entry.getString("input")).append("] ");
            }
            return sb.toString();
        } catch (Exception e) {
            return "Memory unavailable.";
        }
    }

    public void saveNote(String text) {
        try {
            JSONArray notes = loadNotes();
            JSONObject note = new JSONObject();
            note.put("text", text);
            note.put("timestamp", System.currentTimeMillis());
            note.put("date", new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
                .format(new Date()));
            notes.put(note);
            saveToFile(NOTES_FILE, notes.toString());
        } catch (Exception e) {
            Log.e(TAG, "Note save error: " + e.getMessage());
        }
    }

    public JSONArray getAllNotes() {
        return loadNotes();
    }

    public JSONArray getHistory() {
        return loadHistory();
    }

    public void clearHistory() {
        saveToFile(HISTORY_FILE, "[]");
    }

    public void clearNotes() {
        saveToFile(NOTES_FILE, "[]");
    }

    private JSONArray loadHistory() {
        return loadJsonArray(HISTORY_FILE);
    }

    private JSONArray loadNotes() {
        return loadJsonArray(NOTES_FILE);
    }

    private JSONArray loadJsonArray(String filename) {
        try {
            File file = new File(context.getFilesDir(), filename);
            if (!file.exists()) return new JSONArray();
            StringBuilder sb = new StringBuilder();
            try (BufferedReader br = new BufferedReader(new FileReader(file))) {
                String line;
                while ((line = br.readLine()) != null) sb.append(line);
            }
            return new JSONArray(sb.toString());
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    private void saveToFile(String filename, String content) {
        try {
            File file = new File(context.getFilesDir(), filename);
            try (FileWriter fw = new FileWriter(file)) {
                fw.write(content);
            }
        } catch (Exception e) {
            Log.e(TAG, "File save error: " + e.getMessage());
        }
    }
}
