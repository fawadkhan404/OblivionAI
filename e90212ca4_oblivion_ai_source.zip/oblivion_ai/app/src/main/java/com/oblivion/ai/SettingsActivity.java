package com.oblivion.ai;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class SettingsActivity extends AppCompatActivity {

    private static final int PICK_IMAGE = 300;
    private PrefsManager prefs;

    private EditText nameInput, apiKeyInput;
    private Spinner languageSpinner, voiceSpinner;
    private SeekBar rateBar, pitchBar;
    private ImageView profileImage;
    private Switch serviceSwitch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        prefs = new PrefsManager(this);
        initViews();
        loadCurrentSettings();
    }

    private void initViews() {
        nameInput       = findViewById(R.id.nameInput);
        apiKeyInput     = findViewById(R.id.apiKeyInput);
        languageSpinner = findViewById(R.id.languageSpinner);
        voiceSpinner    = findViewById(R.id.voiceSpinner);
        rateBar         = findViewById(R.id.rateBar);
        pitchBar        = findViewById(R.id.pitchBar);
        profileImage    = findViewById(R.id.profileImage);
        serviceSwitch   = findViewById(R.id.serviceSwitch);

        // Language options
        String[] languages = {"Roman Urdu", "Urdu", "English", "Pashto"};
        ArrayAdapter<String> langAdapter = new ArrayAdapter<>(this,
            android.R.layout.simple_spinner_item, languages);
        langAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        languageSpinner.setAdapter(langAdapter);

        // Voice style options
        String[] voices = {"Normal", "Fast", "Slow", "Deep", "High"};
        ArrayAdapter<String> voiceAdapter = new ArrayAdapter<>(this,
            android.R.layout.simple_spinner_item, voices);
        voiceAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        voiceSpinner.setAdapter(voiceAdapter);

        // Profile image picker
        profileImage.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            startActivityForResult(intent, PICK_IMAGE);
        });

        // Save button
        findViewById(R.id.saveBtn).setOnClickListener(v -> saveSettings());

        // Clear history button
        findViewById(R.id.clearHistoryBtn).setOnClickListener(v -> {
            new MemoryManager(this).clearHistory();
            Toast.makeText(this, "History clear kar diya!", Toast.LENGTH_SHORT).show();
        });

        // Back button
        findViewById(R.id.backBtn).setOnClickListener(v -> finish());
    }

    private void loadCurrentSettings() {
        nameInput.setText(prefs.getUserName());
        apiKeyInput.setText(prefs.getApiKey());
        serviceSwitch.setChecked(prefs.isServiceEnabled());

        // Set language spinner
        String lang = prefs.getLanguage();
        int langPos = 0;
        switch (lang) {
            case "ru": langPos = 0; break;
            case "ur": langPos = 1; break;
            case "en": langPos = 2; break;
            case "ps": langPos = 3; break;
        }
        languageSpinner.setSelection(langPos);

        // Rate and pitch
        rateBar.setProgress((int)(prefs.getSpeechRate() * 100));
        pitchBar.setProgress((int)(prefs.getSpeechPitch() * 100));
    }

    private void saveSettings() {
        prefs.setUserName(nameInput.getText().toString().trim());
        prefs.setApiKey(apiKeyInput.getText().toString().trim());
        prefs.setServiceEnabled(serviceSwitch.isChecked());
        prefs.setSpeechRate(rateBar.getProgress() / 100f);
        prefs.setSpeechPitch(pitchBar.getProgress() / 100f);

        String[] langCodes = {"ru", "ur", "en", "ps"};
        prefs.setLanguage(langCodes[languageSpinner.getSelectedItemPosition()]);

        Toast.makeText(this, "Settings save ho gayi! ✅", Toast.LENGTH_SHORT).show();
        finish();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE && resultCode == RESULT_OK && data != null) {
            Uri imageUri = data.getData();
            profileImage.setImageURI(imageUri);
            if (imageUri != null) prefs.setProfileImagePath(imageUri.toString());
        }
    }
}
