package com.oblivion.ai;

import android.content.Context;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.*;
import java.net.*;
import java.util.*;

/**
 * AI Brain — handles conversation, memory, language detection,
 * and calls OpenAI GPT API for intelligent responses.
 */
public class AIBrain {

    private static final String TAG = "AIBrain";
    private static final String API_URL = "https://api.openai.com/v1/chat/completions";

    private final Context context;
    private final PrefsManager prefs;
    private final List<Map<String, String>> conversationHistory;
    private final MemoryManager memory;

    public AIBrain(Context context) {
        this.context = context;
        this.prefs = new PrefsManager(context);
        this.conversationHistory = new ArrayList<>();
        this.memory = new MemoryManager(context);
        initSystemPrompt();
    }

    private void initSystemPrompt() {
        String userName = prefs.getUserName();
        String lang = prefs.getLanguage();
        String langDesc = getLanguageDesc(lang);
        String pastMemory = memory.getSummary();

        String systemPrompt =
            "Tum ek intelligent AI assistant ho jiska naam Oblivion hai. " +
            "Tum Tony Stark ke personal AI ho — bilkul Jarvis ki tarah. " +
            "User ka naam: " + userName + ". " +
            "Primary language: " + langDesc + ". " +
            "Tum Roman Urdu, Urdu, English, aur Pashto mein fluently baat kar sakte ho. " +
            "User jo language use kare, tum usi mein jawab do. " +
            "Friendly, confident, aur helpful raho. Jab command mile toh clearly batao kya karo ge. " +
            "Short responses preferred jab tak detail na manga jaye. " +
            "Past memory: " + pastMemory;

        Map<String, String> sysMsg = new HashMap<>();
        sysMsg.put("role", "system");
        sysMsg.put("content", systemPrompt);
        conversationHistory.add(sysMsg);
    }

    private String getLanguageDesc(String code) {
        switch (code) {
            case "ur": return "Urdu";
            case "ps": return "Pashto";
            case "ru": return "Roman Urdu";
            default:   return "English";
        }
    }

    public String getResponse(String userInput) {
        // Add user message to history
        Map<String, String> userMsg = new HashMap<>();
        userMsg.put("role", "user");
        userMsg.put("content", userInput);
        conversationHistory.add(userMsg);

        // Keep history manageable (last 20 messages + system)
        if (conversationHistory.size() > 21) {
            conversationHistory.remove(1);
        }

        String apiKey = prefs.getApiKey();
        if (apiKey == null || apiKey.isEmpty()) {
            return getFallbackResponse(userInput);
        }

        try {
            return callGPT(apiKey);
        } catch (Exception e) {
            Log.e(TAG, "GPT error: " + e.getMessage());
            return getFallbackResponse(userInput);
        }
    }

    private String callGPT(String apiKey) throws Exception {
        JSONArray messages = new JSONArray();
        for (Map<String, String> msg : conversationHistory) {
            JSONObject obj = new JSONObject();
            obj.put("role", msg.get("role"));
            obj.put("content", msg.get("content"));
            messages.put(obj);
        }

        JSONObject requestBody = new JSONObject();
        requestBody.put("model", "gpt-3.5-turbo");
        requestBody.put("messages", messages);
        requestBody.put("max_tokens", 300);
        requestBody.put("temperature", 0.8);

        URL url = new URL(API_URL);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("Authorization", "Bearer " + apiKey);
        conn.setDoOutput(true);
        conn.setConnectTimeout(10000);
        conn.setReadTimeout(15000);

        try (OutputStream os = conn.getOutputStream()) {
            os.write(requestBody.toString().getBytes("UTF-8"));
        }

        int code = conn.getResponseCode();
        InputStream is = (code == 200) ? conn.getInputStream() : conn.getErrorStream();
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(is, "UTF-8"))) {
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
        }

        if (code == 200) {
            JSONObject resp = new JSONObject(sb.toString());
            String reply = resp.getJSONArray("choices")
                .getJSONObject(0)
                .getJSONObject("message")
                .getString("content")
                .trim();

            // Add assistant response to history
            Map<String, String> assistantMsg = new HashMap<>();
            assistantMsg.put("role", "assistant");
            assistantMsg.put("content", reply);
            conversationHistory.add(assistantMsg);

            return reply;
        } else {
            throw new Exception("API error: " + code + " " + sb);
        }
    }

    private String getFallbackResponse(String input) {
        // Offline fallback responses in Roman Urdu
        String lower = input.toLowerCase();
        if (lower.contains("hello") || lower.contains("hi") || lower.contains("salam"))
            return "Salam! Main Oblivion hoon, aapka personal AI. Batao kya karna hai?";
        if (lower.contains("kya hal") || lower.contains("how are you"))
            return "Main bilkul theek hoon, hamesha ready! Aap batao?";
        if (lower.contains("time") || lower.contains("waqt"))
            return "Waqt check kar raha hoon... please phone ka clock dekho abhi.";
        if (lower.contains("thanks") || lower.contains("shukriya"))
            return "Koi baat nahi! Hamesha haazir hoon.";
        return "Samajh gaya. Abhi internet connection ya API key chahiye iske liye. Settings mein API key add karo.";
    }

    public void saveInteraction(String input, String response) {
        memory.save(input, response);
    }

    public void updateLastResponse(String input, String response) {
        memory.updateLast(input, response);
    }
}
