package com.oblivion.ai;

import android.content.Context;
import android.content.SharedPreferences;

public class PrefsManager {

    private static final String PREF_NAME = "OblivionPrefs";
    private final SharedPreferences prefs;

    public PrefsManager(Context context) {
        prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    public String getUserName() {
        return prefs.getString("user_name", "Tony");
    }

    public void setUserName(String name) {
        prefs.edit().putString("user_name", name).apply();
    }

    public String getLanguage() {
        return prefs.getString("language", "ru"); // Roman Urdu default
    }

    public void setLanguage(String lang) {
        prefs.edit().putString("language", lang).apply();
    }

    public String getApiKey() {
        return prefs.getString("api_key", "");
    }

    public void setApiKey(String key) {
        prefs.edit().putString("api_key", key).apply();
    }

    public String getVoiceStyle() {
        return prefs.getString("voice_style", "normal");
    }

    public void setVoiceStyle(String style) {
        prefs.edit().putString("voice_style", style).apply();
    }

    public String getProfileImagePath() {
        return prefs.getString("profile_image", "");
    }

    public void setProfileImagePath(String path) {
        prefs.edit().putString("profile_image", path).apply();
    }

    public boolean isServiceEnabled() {
        return prefs.getBoolean("service_enabled", true);
    }

    public void setServiceEnabled(boolean enabled) {
        prefs.edit().putBoolean("service_enabled", enabled).apply();
    }

    public float getSpeechRate() {
        return prefs.getFloat("speech_rate", 0.95f);
    }

    public void setSpeechRate(float rate) {
        prefs.edit().putFloat("speech_rate", rate).apply();
    }

    public float getSpeechPitch() {
        return prefs.getFloat("speech_pitch", 0.9f);
    }

    public void setSpeechPitch(float pitch) {
        prefs.edit().putFloat("speech_pitch", pitch).apply();
    }
}
