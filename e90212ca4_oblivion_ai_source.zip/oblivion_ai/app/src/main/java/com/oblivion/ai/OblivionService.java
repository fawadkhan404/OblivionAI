package com.oblivion.ai;

import android.app.*;
import android.content.Intent;
import android.media.*;
import android.os.*;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import androidx.core.app.NotificationCompat;

import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Foreground service — always running, listens for "Oblivion" wake word.
 * Uses Android AudioRecord + simple energy-threshold VAD, then triggers
 * Google Speech Recognition via broadcast when wake word detected.
 */
public class OblivionService extends Service {

    private static final String TAG = "OblivionService";
    private static final int NOTIFICATION_ID = 1;

    private final AtomicBoolean running = new AtomicBoolean(false);
    private Thread listenThread;
    private TextToSpeech tts;
    private AIBrain aiBrain;
    private CommandExecutor commandExecutor;
    private WakeLock wakeLock;

    // Simple keyword detection state
    private static final String WAKE_WORD = "oblivion";

    @Override
    public void onCreate() {
        super.onCreate();
        aiBrain = new AIBrain(this);
        commandExecutor = new CommandExecutor(this);
        initTTS();
        acquireWakeLock();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startForeground(NOTIFICATION_ID, buildNotification());
        startListening();
        return START_STICKY; // Restart if killed
    }

    private void startListening() {
        if (running.get()) return;
        running.set(true);

        listenThread = new Thread(() -> {
            Log.d(TAG, "Listening thread started");
            // Use Android SpeechRecognizer continuously via broadcast approach
            // The service sends a broadcast to MainActivity to trigger voice input
            // when wake word energy pattern is detected in mic stream
            continuousListen();
        });
        listenThread.setDaemon(true);
        listenThread.start();
    }

    private void continuousListen() {
        int sampleRate = 16000;
        int bufferSize = AudioRecord.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        ) * 4;

        AudioRecord recorder = null;
        try {
            recorder = new AudioRecord(
                MediaRecorder.AudioSource.VOICE_RECOGNITION,
                sampleRate,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                bufferSize
            );

            if (recorder.getState() != AudioRecord.STATE_INITIALIZED) {
                Log.e(TAG, "AudioRecord init failed");
                return;
            }

            recorder.startRecording();
            short[] buffer = new short[bufferSize / 2];
            long silenceStart = System.currentTimeMillis();
            boolean speechDetected = false;

            while (running.get()) {
                int read = recorder.read(buffer, 0, buffer.length);
                if (read > 0) {
                    double rms = calculateRMS(buffer, read);

                    // Voice Activity Detection - energy threshold
                    if (rms > 800) { // Speech energy threshold
                        if (!speechDetected) {
                            speechDetected = true;
                            // Signal MainActivity to start speech recognition
                            sendWakeSignal();
                        }
                        silenceStart = System.currentTimeMillis();
                    } else {
                        if (System.currentTimeMillis() - silenceStart > 2000) {
                            speechDetected = false;
                        }
                    }
                }
                // Small sleep to reduce CPU usage
                try { Thread.sleep(50); } catch (InterruptedException ignored) {}
            }

        } catch (SecurityException e) {
            Log.e(TAG, "No mic permission: " + e.getMessage());
        } finally {
            if (recorder != null) {
                recorder.stop();
                recorder.release();
            }
        }
    }

    private double calculateRMS(short[] buffer, int length) {
        long sum = 0;
        for (int i = 0; i < length; i++) {
            sum += (long) buffer[i] * buffer[i];
        }
        return Math.sqrt((double) sum / length);
    }

    private void sendWakeSignal() {
        Intent intent = new Intent("com.oblivion.WAKE_WORD_DETECTED");
        sendBroadcast(intent);
        Log.d(TAG, "Wake signal sent");
    }

    private void initTTS() {
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                PrefsManager prefs = new PrefsManager(this);
                String lang = prefs.getLanguage();
                Locale locale = lang.equals("ur") ? new Locale("ur") : Locale.ENGLISH;
                tts.setLanguage(locale);
            }
        });
    }

    private void acquireWakeLock() {
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        if (pm != null) {
            wakeLock = pm.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK,
                "OblivionAI::ListenerLock"
            );
            wakeLock.acquire(); // held as long as service runs
        }
    }

    private Notification buildNotification() {
        Intent notifIntent = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(
            this, 0, notifIntent,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        return new NotificationCompat.Builder(this, OblivionApp.CHANNEL_ID)
            .setContentTitle("Oblivion AI")
            .setContentText("Listening... Say 'Oblivion' to activate")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pi)
            .setOngoing(true)
            .setSilent(true)
            .build();
    }

    @Override
    public void onDestroy() {
        running.set(false);
        if (listenThread != null) listenThread.interrupt();
        if (tts != null) { tts.stop(); tts.shutdown(); }
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
