package com.oblivion.ai;

import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONObject;

public class ChatHistoryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        ListView listView = findViewById(R.id.historyListView);
        MemoryManager mem = new MemoryManager(this);
        JSONArray history = mem.getHistory();

        String[] items = new String[history.length()];
        for (int i = history.length() - 1; i >= 0; i--) {
            try {
                JSONObject entry = history.getJSONObject(i);
                String date = entry.optString("date", "");
                String input = entry.optString("input", "");
                String response = entry.optString("response", "");
                items[history.length() - 1 - i] = date + "\n" + input + "\n→ " + response;
            } catch (Exception e) {
                items[history.length() - 1 - i] = "Error loading entry";
            }
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
            android.R.layout.simple_list_item_1, items);
        listView.setAdapter(adapter);

        findViewById(R.id.backBtn).setOnClickListener(v -> finish());
    }
}
